import express from "express";
import {
  registerSeeker,
  getAllSeekers,
} from "../controllers/seekerController.js";

const router = express.Router();

router.post("/register", registerSeeker);
router.get("/", getAllSeekers);

export default router;
