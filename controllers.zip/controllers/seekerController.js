import Seeker from "../models/seeker.js";

export const registerSeeker = async (req, res) => {
  try {
    const data = req.body;
    if (!data.fullName || !data.email)
      return res
        .status(400)
        .json({ message: "Full name and email are required" });

    const existingSeeker = await Seeker.findOne({ email: data.email });
    if (existingSeeker)
      return res
        .status(409)
        .json({ message: "Seeker with this email already exists" });

    if (data.skills && typeof data.skills === "string") {
      data.skills = data.skills.split(",").map((skill) => skill.trim());
    }

    const seeker = await Seeker.create(data);
    res
      .status(201)
      .json({
        status: "success",
        message: "Seeker registered successfully",
        seeker,
      });
  } catch (err) {
    res.status(500).json({ message: "Server error" });
  }
};

export const getAllSeekers = async (req, res) => {
  try {
    const seekers = await Seeker.find();
    res.status(200).json(seekers);
  } catch (err) {
    res.status(500).json({ message: "Server error" });
  }
};
